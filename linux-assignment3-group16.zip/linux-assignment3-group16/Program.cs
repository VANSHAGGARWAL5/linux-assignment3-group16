using System;
using System.IO;
using System.Collections.Generic;
using System.Text.Json;

namespace LinuxAssignment3
{
    class Program
    {
        static void Main(string[] args)
        {
            string jsonFile = "linux_commands.json";
            if (!File.Exists(jsonFile))
            {
                Console.WriteLine($"ERROR: JSON file not found: {jsonFile}");
                return;
            }

            try
            {
                string json = File.ReadAllText(jsonFile);
                var options = new JsonSerializerOptions { PropertyNameCaseInsensitive = true };
                List<Blueprint> commands = JsonSerializer.Deserialize<List<Blueprint>>(json, options);

                Console.WriteLine($"Loaded {commands?.Count ?? 0} commands from {jsonFile}");
                Console.WriteLine("\n--- Command List ---\n");

                if (commands != null)
                {
                    foreach (var cmd in commands)
                    {
                        Console.WriteLine(cmd.ToString());
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("An error occurred while reading or parsing the JSON file:");
                Console.WriteLine(ex.Message);
            }
        }
    }
}

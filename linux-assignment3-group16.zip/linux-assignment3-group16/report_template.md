# Assignment #3 — Report Template

**Course:** Linux (fill course code)  
**Assignment #:** 3  
**Group #:** 16  
**Group Members:** Vansh Aggarwal, Simranjot, Ekta Kaur

---

## Cover Page
Include:
- Assignment #
- Course
- Group #
- Member names
- Date

---

## Table of Contents

1. Introduction
2. Repo structure (screenshot of VS Code Explorer)
3. How to run (screenshot of terminal showing `dotnet run`)
4. JSON file contents
5. Code snippets: Blueprint.cs and Program.cs (screenshots)
6. Testing & Output (terminal screenshot showing the app output)
7. Conclusion

---

### Screenshot labels (example)
- `Figure 1: VS Code Explorer — Project folder structure`
- `Figure 2: Terminal — dotnet run output`
- `Figure 3: Codespaces — Extensions installed (C# / C# Dev Kit)`
- `Figure 4: JSON File open in editor`

---

### Instructions to produce the PDF
1. Open this `report_template.md` or copy into MS Word / Google Docs.
2. Replace placeholders and paste your screenshots in the labeled sections.
3. Export/Save as PDF.

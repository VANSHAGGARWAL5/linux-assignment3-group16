# linux-assignment3-group16

**Assignment #3 — Linux Commands Console App (C# .NET Console Application)**

**Group Number:** 16  
**Group Members:** Vansh Aggarwal, Simranjot, Ekta Kaur

## Project Overview
This is a small .NET console application that reads a JSON file containing Linux commands and displays each command with details using a Blueprint class.

## How to run (local or Codespaces)
1. Ensure .NET SDK (7.0 or later) is installed.
2. Open the folder in VS Code or Codespaces.
3. Restore/build and run:
```bash
dotnet run
```
4. The app reads `linux_commands.json` and prints each command details to the terminal.

## Project Structure
- `linux_commands.json` — JSON data file containing Linux command objects.
- `Blueprint.cs` — C# class that defines the data structure.
- `Program.cs` — Main program: reads JSON and displays command info.
- `linux-assignment3-group16.csproj` — .NET project file.
- `README.md` — This file.

## Commit message examples
- `Initial commit: project scaffold`
- `Added linux_commands.json with 7 commands`
- `Added Blueprint.cs and Program.cs`
- `Updated README with group info`
- `Added report template`

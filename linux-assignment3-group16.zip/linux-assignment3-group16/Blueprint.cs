using System.Text.Json.Serialization;

namespace LinuxAssignment3
{
    public class Blueprint
    {
        [JsonPropertyName("name")]
        public string Name { get; set; }

        [JsonPropertyName("description")]
        public string Description { get; set; }

        [JsonPropertyName("syntax")]
        public string Syntax { get; set; }

        [JsonPropertyName("example")]
        public string Example { get; set; }

        [JsonPropertyName("options")]
        public string Options { get; set; }

        [JsonPropertyName("category")]
        public string Category { get; set; }

        [JsonPropertyName("notes")]
        public string Notes { get; set; }

        public override string ToString()
        {
            return $@"Command: {Name}
Description: {Description}
Category: {Category}
Syntax: {Syntax}
Options: {Options}
Example: {Example}
Notes: {Notes}
-------------------------";
        }
    }
}
